// ==UserScript==
// @name         Google Presearch
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://presearch.com/search?q=*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=presearch.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    const clicarGoogle = document.querySelectorAll('a')[51];
                                               console.log(clicarGoogle);
    clicarGoogle.click();
    console.log(typeof clicarGoogle);
    console.log('Pegou');
})();

