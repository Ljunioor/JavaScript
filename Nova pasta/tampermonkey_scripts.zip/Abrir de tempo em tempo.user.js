// ==UserScript==
// @name         Abrir de tempo em tempo
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://presearch.com/?utm_source=extcr
// @icon         https://www.google.com/s2/favicons?sz=64&domain=presearch.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    var frutas = ["Mão+de+Buda", "Pepino+africano", "Sapota+Preta", "Durian", "Monstera+Deliciosa+ou+Costela+de+adão", "Physalis", "Limonia", "Rambutan", "Pitomba", "Carambola", "Graviola", "Jabuticaba", "Noni", "Pitaya+Amarela", "Phisalys", "Tamarillo+ou+Tomate+de+Árvore", "Ugli+Fruit+ou+Fruta+feia", "Kiwano+ou+Melão+Africano", "Cacau+(fruta)", "Atemoia"];
const indiceAleatorio = Math.floor(Math.random() * frutas.length);
const palavraSorteada = frutas[indiceAleatorio];
console.log(palavraSorteada);





  window.open("https://presearch.com/search?q=".concat(palavraSorteada));
console.log('https://presearch.com/search?q='.concat(palavraSorteada))


    //600000 10 min
    // Your code here...
})();