// ==UserScript==
// @name         Links 99 Pegando
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.99freelas.com.br/project-notifications/view?limit=50
// @icon         https://www.google.com/s2/favicons?sz=64&domain=99freelas.com.br
// @grant        none
// ==/UserScript==

(function coletarLi() {
    'use strict';
    //Palavras Buscadas
    var palavras = ['Landing Page','Landing Pages', 'landing page','landing pages', 'landing Page','landing Pages',
                    'Landing page','Landing pages','figma', 'Figma','site','Site','Website','website','app','App','Wordpress','wordpress','Elementor','elementor',
                   'pagina de venda','pagina de vendas','Pagina de venda','Pagina de vendas','página de venda','página de vendas','Página de venda','Página de vendas',
                   'pagina de Venda','pagina de Vendas','Pagina de Venda','Pagina de Vendas','página de Venda','página de Vendas','Página de Venda','Página de Vendas',
                   'pagina de lançamento','pagina de lançamento','Pagina de lançamento','Pagina de lançamento','página de lançamento','página de lançamento','Página de lançamento','Página de lançamento',
                   'pagina de Lançamento','pagina de Lançamento','Pagina de Lançamento','Pagina de Lançamento','página de Lançamento','página de Lançamento','Página de Lançamento','Página de Lançamento',
                   'lançamento','Lançamento','UX','ux','UI','ui'];

    //Pega as li Todas
    const termos = 'teste';
     const li = document.querySelectorAll('li');

    //Filtro que tenham a classe: 'result-item'; ou seja os job
    let filtro = Array.prototype.filter.call(li, (cadaLi) => {
        return cadaLi.classList.contains('result-item')
    });
    const arrayNova =[];

    for (var i = 0; i < filtro.length; i++) {
    var titulo = filtro[i].querySelector('hgroup div');
    var descricao = filtro[i].querySelectorAll('div:last-of-type');

    let tituloDescricao = titulo.textContent + ' ' + descricao.textContent;

        if(palavras.some(function(palavra){return tituloDescricao.includes(palavra)}))
        {filtro[i].classList.add('clicar'); arrayNova.push(filtro[i]);}
        //else{filtro[i].style.display='none'};
}
    const clicaveis = document.querySelectorAll('.clicar');
    let links = [];
    for(var b = 0; b<clicaveis.length; b++){
        links.push(clicaveis[b].querySelector('a').href);
    }

    for(var x = 0; x<links.length; x++){
        var novaJanela = window.open(links[x], '_blank');

        if (!novaJanela || novaJanela.closed || typeof novaJanela.closed=='undefined') {
          console.log('A abertura da nova janela foi bloqueada pelo navegador.');
        }
    }
})();