// ==UserScript==
// @name         Inserir Script na proposta
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.99freelas.com.br/project/bid/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=99freelas.com.br
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
const textArea = document.querySelector('textarea');
let nome = document.querySelectorAll('span.name')[1];
    console.log(nome);
    let nomeValue = nome.innerHTML
    console.log(nomeValue);
    //recortar
    nomeValue = nomeValue.substring(0, nomeValue.length -2);

    textArea.value = 'Olá '+nomeValue+',tudo bom ? \n\n\n\n Acredito que esteja buscando um serviço profissional para conseguir proporcionar uma boa experiência ao seus clientes, desta forma trabalhar a identidade de marca bem como boa usabilidade de página se torna essencial no desenvolvimento de sua solução\n\nVou enviar uns anexos de exemplo a seguir comprovando que tenho experiência na criação e otimização de paginas\n\nEstou qualificando está conta do 99freelas então coloquei um valor abaixo da média como incentivo de escolha\n\nBÔNUS:\n*Ao termino de meus serviços forneço uma cópia de segurança do projeto final!\n* Faço a instalação do Google Analytics sem custo adicional, assim você pode acompanhar e impulsionar seus resultados online - Opcional\n*Instalação de Site Map google (indexação do site no google) - Opcional\n*Reunião explicativa de melhores estratégias para desenvolver seu funil de venda com o serviço - Opcional\n\nConheça alguns de meus projetos:\nhttps://behance.net/LeonardoBandeira\n\nUm pouco sobre mim:\nMeu nome é Leonardo, Tenho experiência de 3 anos em desenvolvimento web e tenho conhecimento em diversas tecnologias. Sou super atencioso com meus clientes e o suporte prestado no pós entrega não deixa a desejar, desenvolvendo soluções com reuniões online.\nJá trabalhei como front-end em grandes agências do Brasil me dedicando tanto para desenvolvimento de programação voltada a web e mobile quanto a criação de layouts e identidades visuais. Tenho trabalhado atualmente tanto em parceria com agências quanto diretamente para o cliente final. Desenvolvo sites em HTML/CSS/JS puro ou utilizando ferramentas como o Wordpress.\n\nMeu site é este aqui: https://leobandeira.com/\n\nSEO aplicado.\n\nPor favor, me avise se você tiver alguma dúvida ou se estiver interesse em prosseguir com a proposta'
    console.log(textArea);
    // Your code here...
})();